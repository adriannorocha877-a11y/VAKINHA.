"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"

export default function VakinhaClone() {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null)
  const [customAmount, setCustomAmount] = useState("")
  const [showPixCheckout, setShowPixCheckout] = useState(false)
  const [pixData, setPixData] = useState<any | null>(null)
  const [copied, setCopied] = useState(false)
  const [comment, setComment] = useState("")
  const [donorName, setDonorName] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showNotification, setShowNotification] = useState(false)
  const [showWelcomeNotification, setShowWelcomeNotification] = useState(false)

  const campaignData = {
    id: "VK-2024-7892",
    title: "Ajuda para Verônica - Tratamento contra Hipofosfatasia",
    description:
      "Verônica precisa da nossa ajuda para continuar seu tratamento contra a hipofosfatasia. Cada doação faz a diferença na vida dela e de sua família. Juntos podemos ajudá-la a ter uma vida mais saudável e feliz.",
    goal: 500000, // R$ 5.000 em centavos
    raised: 235000, // R$ 2.350 em centavos (47% da meta)
    donors: 156,
    daysLeft: 45,
    image: "/veronica-campaign.jpg",
  }

  const progressPercentage = (campaignData.raised / campaignData.goal) * 100

  const handleDonationClick = async () => {
    const amount = selectedAmount || Number.parseFloat(customAmount)
    if (amount && amount > 0) {
      setLoading(true)
      setError(null)

      try {
        await generatePixCode(amount)
        setShowPixCheckout(true)
      } catch (err) {
        setError("Erro ao gerar código Pix. Tente novamente.")
        console.error("Erro ao gerar Pix:", err)
      } finally {
        setLoading(false)
      }
    }
  }

  const generatePixCode = async (amount: number) => {
    const API_BASE_URL = "https://api.pushinpay.com.br"
    const API_TOKEN = "42369|XU1yxGawOKM7NETc1dhQh6bUdGNDYuzTS3r0clRUe3363775"
    const WEBHOOK_URL = "https://seu-site.com/webhook"

    try {
      const response = await fetch(`${API_BASE_URL}/api/pix/cashIn`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${API_TOKEN}`,
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          value: Math.round(amount * 100),
          webhook_url: WEBHOOK_URL,
          split_rules: [],
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const data = await response.json()
      setPixData(data)

      showSuccessNotification()

      localStorage.setItem("transaction_id", data.id)
    } catch (error) {
      console.error("Erro ao gerar código Pix:", error)
      throw error
    }
  }

  const checkPaymentStatus = async (transactionId: string) => {
    const API_BASE_URL = "https://api.pushinpay.com.br"
    const API_TOKEN = "42369|XU1yxGawOKM7NETc1dhQh6bUdGNDYuzTS3r0clRUe3363775"

    try {
      const response = await fetch(`${API_BASE_URL}/api/transactions/${transactionId}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${API_TOKEN}`,
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        return data.status
      }
      return null
    } catch (error) {
      console.error("Erro ao consultar status:", error)
      return null
    }
  }

  const copyPixCode = () => {
    if (pixData?.qr_code) {
      navigator.clipboard.writeText(pixData.qr_code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const scrollToDonation = () => {
    const donationSection = document.getElementById("donation-section")
    if (donationSection) {
      donationSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  const scrollToDescription = () => {
    const descriptionSection = document.getElementById("description-section")
    if (descriptionSection) {
      descriptionSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  const playNotificationSound = () => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()

    const frequencies = [523, 659, 784]

    frequencies.forEach((freq, index) => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.setValueAtTime(freq, audioContext.currentTime + index * 0.1)
      oscillator.type = "sine"

      gainNode.gain.setValueAtTime(0, audioContext.currentTime + index * 0.1)
      gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + index * 0.1 + 0.05)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + index * 0.1 + 0.4)

      oscillator.start(audioContext.currentTime + index * 0.1)
      oscillator.stop(audioContext.currentTime + index * 0.1 + 0.4)
    })
  }

  const showSuccessNotification = () => {
    setShowNotification(true)
    playNotificationSound()
    setTimeout(() => setShowNotification(false), 4000)
  }

  const randomNames = [
    "Ana Silva",
    "Carlos Santos",
    "Maria Oliveira",
    "João Pereira",
    "Fernanda Costa",
    "Pedro Almeida",
    "Juliana Lima",
    "Rafael Souza",
    "Camila Rodrigues",
    "Lucas Ferreira",
    "Beatriz Martins",
    "Gabriel Nascimento",
    "Larissa Barbosa",
    "Thiago Ribeiro",
    "Amanda Carvalho",
  ]

  const getRandomName = () => {
    return randomNames[Math.floor(Math.random() * randomNames.length)]
  }

  const playDropSound = () => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()

    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    // Som de gota: frequência alta que desce rapidamente
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime)
    oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.3)
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0, audioContext.currentTime)
    gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.02)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.3)
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcomeNotification(true)
      playDropSound()

      setTimeout(() => {
        setShowWelcomeNotification(false)
      }, 5000)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (showPixCheckout) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-md mx-auto px-4">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-green-600">Finalizar Doação</CardTitle>
              <CardDescription>
                Valor: R$ {(selectedAmount || Number.parseFloat(customAmount)).toFixed(2)}
              </CardDescription>
              {pixData && <div className="text-xs text-gray-500">ID: {pixData.id}</div>}
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center">
                {pixData?.qr_code_base64 ? (
                  <img
                    src={pixData.qr_code_base64 || "/placeholder.svg"}
                    alt="QR Code Pix"
                    className="w-48 h-48 border-2 border-gray-200 rounded-lg"
                  />
                ) : (
                  <div className="w-48 h-48 bg-white border-2 border-gray-200 rounded-lg flex items-center justify-center">
                    <svg viewBox="0 0 40 40" className="h-12 w-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect x="2" y="2" width="28" height="22" rx="6" fill="white" />
                      <path d="M8 24 L12 30 L16 24" fill="white" />
                      <path
                        d="M10 8 L15 20 L20 8"
                        stroke="#1f2937"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        fill="none"
                      />
                    </svg>
                    <div className="absolute text-xs text-gray-500 mt-32">QR Code Pix</div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Código Pix (Copia e Cola)</label>
                <div className="flex gap-2">
                  <Input value={pixData?.qr_code || ""} readOnly className="text-xs" />
                  <Button variant="outline" size="sm" onClick={copyPixCode} className="shrink-0 bg-transparent">
                    {copied ? (
                      <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M9 12L11 14L15 10"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M8 16V8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M18 13L13 18"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    )}
                  </Button>
                </div>
              </div>

              {pixData && (
                <div className="bg-yellow-50 p-3 rounded-lg">
                  <div className="text-sm">
                    <strong>Status:</strong>{" "}
                    {pixData.status === "created"
                      ? "Aguardando pagamento"
                      : pixData.status === "paid"
                        ? "Pago ✅"
                        : pixData.status === "expired"
                          ? "Expirado"
                          : pixData.status}
                  </div>
                </div>
              )}

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Como pagar:</h4>
                <ol className="text-sm text-blue-800 space-y-1">
                  <li>1. Abra o app do seu banco</li>
                  <li>2. Escaneie o QR Code ou copie o código</li>
                  <li>3. Confirme o pagamento</li>
                  <li>4. Pronto! Sua doação será processada</li>
                </ol>
              </div>

              <div className="bg-gray-50 p-3 rounded-lg text-xs text-gray-600">
                <p>
                  <strong>Importante:</strong> A PUSHIN PAY atua exclusivamente como processadora de pagamentos e não
                  possui qualquer responsabilidade pela entrega, suporte, conteúdo, qualidade ou cumprimento das
                  obrigações relacionadas aos produtos ou serviços oferecidos pelo vendedor.
                </p>
              </div>

              <Button variant="outline" className="w-full bg-transparent" onClick={() => setShowPixCheckout(false)}>
                Voltar
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="fixed bottom-6 right-6 z-50 cursor-pointer group" onClick={scrollToDonation}>
        <div className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 animate-pulse hover:scale-110">
          <svg
            viewBox="0 0 24 24"
            className="w-8 h-8 animate-pulse"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
        <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-800 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
          Clique para doar ❤️
        </div>
        <div className="absolute inset-0 rounded-full bg-green-500 animate-ping opacity-20"></div>
        <div
          className="absolute inset-0 rounded-full bg-green-500 animate-ping opacity-10"
          style={{ animationDelay: "0.5s" }}
        ></div>
      </div>

      {showNotification && (
        <div className="fixed top-4 right-4 z-50 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 animate-in slide-in-from-right duration-300">
          <div className="flex-shrink-0">
            <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M9 12L11 14L15 10"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div>
            <div className="font-semibold">QR Code gerado com sucesso!</div>
            <div className="text-sm opacity-90">Seu código Pix está pronto para pagamento</div>
          </div>
          <button
            onClick={() => setShowNotification(false)}
            className="flex-shrink-0 ml-4 text-white hover:text-gray-200"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      )}

      {showWelcomeNotification && (
        <div className="fixed bottom-4 left-4 z-50 bg-white border border-green-200 shadow-lg rounded-lg p-4 max-w-sm animate-in slide-in-from-left duration-500">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <span className="font-medium text-green-600">A</span>
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">Ana Silva</span>
                <span className="text-gray-500 ml-2">doou R$ 50</span>
              </div>
              <p className="text-gray-700">Que Deus abençoe seus estudos, Verônica! 🙏</p>
            </div>
            <button
              onClick={() => setShowWelcomeNotification(false)}
              className="flex-shrink-0 text-gray-400 hover:text-gray-600"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M18 6L6 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M6 6L18 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      )}

      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/vakinha-logo.png" alt="Vakinha" className="h-10 w-auto" />
            </div>
            <div className="flex gap-4">
              <Button variant="outline" className="bg-transparent" onClick={scrollToDescription}>
                História
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-0">
                <img
                  src={campaignData.image || "/placeholder.svg"}
                  alt={campaignData.title}
                  className="w-full h-64 object-cover rounded-t-lg"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-bold">{campaignData.title}</CardTitle>
                <div className="text-sm text-gray-500 mb-2">
                  ID da campanha: <span className="font-mono font-medium">{campaignData.id}</span>
                </div>
                <div className="flex items-center gap-4 text-gray-600">
                  <div className="flex items-center gap-1">
                    <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M18 20V10C18 8.89543 17.1046 8 16 8H8C6.89543 8 6 8.89543 6 10V20C6 21.1046 6.89543 22 8 22H16C17.1046 22 18 21.1046 18 20Z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 12V16"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 8V12"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    {campaignData.donors} doadores
                  </div>
                  <div className="flex items-center gap-1">
                    <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M12 22C14.7614 22 17 19.7614 17 17C17 14.2386 14.7614 12 12 12C9.23858 12 7 14.2386 7 17C7 19.7614 9.23858 22 12 22Z"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M12 8V12"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    {campaignData.daysLeft} dias restantes
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-base text-gray-700 leading-relaxed">{campaignData.description}</p>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-bold text-green-600">
                      R$ {(campaignData.raised / 100).toLocaleString("pt-BR")}
                    </span>
                    <span className="text-gray-600">de R$ {(campaignData.goal / 100).toLocaleString("pt-BR")}</span>
                  </div>
                  <div className="relative">
                    <Progress value={progressPercentage} className="h-4 transition-all duration-1000 ease-out" />
                    <div
                      className="absolute top-0 left-0 h-4 bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-2000 ease-out animate-pulse"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                  <div className="text-gray-600">{progressPercentage.toFixed(1)}% da meta alcançada</div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-white rounded-lg shadow-sm p-6 mb-6" id="description-section">
              <h2 className="text-2xl font-bold mb-4">Nossa História</h2>
              <div className="prose max-w-none">
                <p className="text-gray-700 mb-4">
                  A Verônica é uma jovem guerreira que enfrenta a Hipofosfatasia, uma doença rara que afeta o
                  desenvolvimento dos ossos e dentes. Sua família precisa da nossa ajuda para custear o tratamento
                  especializado e os medicamentos necessários.
                </p>
                <p className="text-gray-700 mb-4">
                  Cada doação faz a diferença na vida da Verônica e representa esperança para sua recuperação. Com o
                  apoio de pessoas como você, ela pode ter acesso aos cuidados médicos essenciais.
                </p>
                <p className="text-gray-700 mb-4">
                  Junte-se a nós nesta causa e ajude a Verônica a ter uma vida mais saudável e feliz. Sua contribuição,
                  independente do valor, é muito importante para nós.
                </p>

                <div className="mt-6 p-4 bg-gray-50 rounded-lg border">
                  <h3 className="text-lg font-semibold mb-3 text-gray-800">Documentação Médica</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Atestado médico oficial comprovando o diagnóstico e necessidade de tratamento:
                  </p>
                  <div className="bg-white p-2 rounded border">
                    <img
                      src="/atestado-medico.png"
                      alt="Atestado médico da Verônica Costa da Silva - Epidermólise Bolhosa Hereditária"
                      className="w-full h-auto rounded shadow-sm"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Documento emitido pelo Hospital de Santamaria - Dr. José Roberto de Souza (CRM 17984 SP)
                  </p>
                </div>
              </div>
            </div>

            <Card className="lg:hidden" id="donation-section">
              <CardHeader>
                <CardTitle className="text-xl text-green-600">Quero Ajudar</CardTitle>
                <CardDescription>Escolha o valor da sua doação</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {[10, 30, 50, 70, 100, 125].map((amount) => (
                    <Button
                      key={amount}
                      variant={selectedAmount === amount ? "default" : "outline"}
                      className={`${selectedAmount === amount ? "bg-green-500 hover:bg-green-600" : ""}`}
                      onClick={() => {
                        setSelectedAmount(amount)
                        setCustomAmount("")
                      }}
                    >
                      R$ {amount}
                    </Button>
                  ))}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Outro valor</label>
                  <Input
                    type="number"
                    placeholder="R$ 0,00"
                    value={customAmount}
                    max="150"
                    onChange={(e) => {
                      const value = e.target.value
                      if (Number(value) <= 150 || value === "") {
                        setCustomAmount(value)
                        setSelectedAmount(null)
                      }
                    }}
                  />
                  <p className="text-xs text-gray-500">Limite máximo: R$ 150,00</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Seu nome (opcional)</label>
                  <Input
                    placeholder="Como você quer aparecer"
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Deixe um comentário (opcional)</label>
                  <Textarea
                    placeholder="Deixe uma mensagem de apoio..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={3}
                  />
                </div>

                <Button
                  className="w-full bg-green-500 hover:bg-green-600"
                  onClick={handleDonationClick}
                  disabled={(!selectedAmount && !customAmount) || loading}
                >
                  {loading ? (
                    <>
                      <svg
                        viewBox="0 0 24 24"
                        className="w-4 h-4 mr-2 animate-spin"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M12 2c-.55 0-1 .45-1 1v-10c0-.55.45-1 1-1s1 .45 1 1v10c0 .55-.45 1-1 1zm-7 7c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8-8-3.59-8-8z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      Gerando Pix...
                    </>
                  ) : (
                    <>
                      <svg viewBox="0 0 24 24" className="w-4 h-4 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M12 22c-.55 0-1-.45-1-1v-10c0-.55.45-1 1-1s1 .45 1 1v10c0 .55-.45 1-1 1zm-7 7c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8-8-3.59-8-8z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      Quero Ajudar
                    </>
                  )}
                </Button>

                {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">{error}</div>}

                <div className="text-sm text-gray-500 text-center">
                  <p>🔒 Pagamento 100% seguro via Pix</p>
                  <p>Integração com PushinPay</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M21 15V6C21 4.89543 20.1046 4 19 4H5C3.89543 4 3 4.89543 3 6V15C3 16.1046 3.89543 17 5 17h14c1.10457 0 2-.89543 2-2z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M17 8c0-.55-.45-1-1-1H5c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h14c.55 0 1-.45 1-1V8z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M8 12h8"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  Comentários dos doadores
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-green-600">A</span>
                      </div>
                      <div>
                        <span className="font-medium">Ana Silva</span>
                        <span className="text-gray-500 ml-2">doou R$ 50</span>
                      </div>
                    </div>
                    <p className="text-gray-700">
                      Força Verônica! Que você consiga o tratamento para a Hipofosfatasia! 🙏
                    </p>
                  </div>

                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-blue-600">J</span>
                      </div>
                      <div>
                        <span className="font-medium">João Santos</span>
                        <span className="text-gray-500 ml-2">doou R$ 100</span>
                      </div>
                    </div>
                    <p className="text-gray-700">Minha filha também tem uma doença rara. Não desistam! 💪</p>
                  </div>

                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-purple-600">M</span>
                      </div>
                      <div>
                        <span className="font-medium">Maria Oliveira</span>
                        <span className="text-gray-500 ml-2">doou R$ 30</span>
                      </div>
                    </div>
                    <p className="text-gray-700">Que os médicos encontrem o melhor tratamento para você! ✨</p>
                  </div>

                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-orange-600">C</span>
                      </div>
                      <div>
                        <span className="font-medium">Carlos Pereira</span>
                        <span className="text-gray-500 ml-2">doou R$ 75</span>
                      </div>
                    </div>
                    <p className="text-gray-700">
                      Toda vida importa! Vamos juntos nessa luta contra as doenças raras! 👏
                    </p>
                  </div>

                  <div className="border-b pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-pink-600">L</span>
                      </div>
                      <div>
                        <span className="font-medium">Lucia Costa</span>
                        <span className="text-gray-500 ml-2">doou R$ 25</span>
                      </div>
                    </div>
                    <p className="text-gray-700">Que você se recupere logo e volte a sorrir! Torcendo por vocês! 💪</p>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-indigo-600">R</span>
                      </div>
                      <div>
                        <span className="font-medium">Roberto Lima</span>
                        <span className="text-gray-500 ml-2">doou R$ 60</span>
                      </div>
                    </div>
                    <p className="text-gray-700">A medicina avança cada dia! Tenha fé no seu tratamento! 🩺</p>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                        <span className="font-medium text-teal-600">F</span>
                      </div>
                      <div>
                        <span className="font-medium">Fernanda Souza</span>
                        <span className="text-gray-500 ml-2">doou R$ 40</span>
                      </div>
                    </div>
                    <p className="text-gray-700">Família unida vence qualquer batalha! Força para vocês! 🌟</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6 hidden lg:block">
            <Card className="sticky top-4" id="donation-section">
              <CardHeader>
                <CardTitle className="text-xl text-green-600">Quero Ajudar</CardTitle>
                <CardDescription>Escolha o valor da sua doação</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {[10, 30, 50, 70, 100, 125].map((amount) => (
                    <Button
                      key={amount}
                      variant={selectedAmount === amount ? "default" : "outline"}
                      className={`${selectedAmount === amount ? "bg-green-500 hover:bg-green-600" : ""}`}
                      onClick={() => {
                        setSelectedAmount(amount)
                        setCustomAmount("")
                      }}
                    >
                      R$ {amount}
                    </Button>
                  ))}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Outro valor</label>
                  <Input
                    type="number"
                    placeholder="R$ 0,00"
                    value={customAmount}
                    max="150"
                    onChange={(e) => {
                      const value = e.target.value
                      if (Number(value) <= 150 || value === "") {
                        setCustomAmount(value)
                        setSelectedAmount(null)
                      }
                    }}
                  />
                  <p className="text-xs text-gray-500">Limite máximo: R$ 150,00</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Seu nome (opcional)</label>
                  <Input
                    placeholder="Como você quer aparecer"
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Deixe um comentário (opcional)</label>
                  <Textarea
                    placeholder="Deixe uma mensagem de apoio..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={3}
                  />
                </div>

                <Button
                  className="w-full bg-green-500 hover:bg-green-600"
                  onClick={handleDonationClick}
                  disabled={(!selectedAmount && !customAmount) || loading}
                >
                  {loading ? (
                    <>
                      <svg
                        viewBox="0 0 24 24"
                        className="w-4 h-4 mr-2 animate-spin"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M12 2c-.55 0-1 .45-1 1v-10c0-.55.45-1 1-1s1 .45 1 1v10c0 .55-.45 1-1 1zm-7 7c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8-8-3.59-8-8z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      Gerando Pix...
                    </>
                  ) : (
                    <>
                      <svg viewBox="0 0 24 24" className="w-4 h-4 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M12 22c-.55 0-1-.45-1-1v-10c0-.55.45-1 1-1s1 .45 1 1v10c0 .55-.45 1-1 1zm-7 7c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8-8-3.59-8-8z"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      Quero Ajudar
                    </>
                  )}
                </Button>

                {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">{error}</div>}

                <div className="text-sm text-gray-500 text-center">
                  <p>🔒 Pagamento 100% seguro via Pix</p>
                  <p>Integração com PushinPay</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                      d="M6 2L3 6v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3 4z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M18 19a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  Compartilhar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    WhatsApp
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    Facebook
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-green-600">{campaignData.donors}</div>
                    <div className="text-sm text-gray-600">Doadores</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">{campaignData.daysLeft}</div>
                    <div className="text-sm text-gray-600">Dias restantes</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <footer className="bg-gray-800 text-white py-12 mt-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between mb-8 pb-6 border-b border-gray-700">
            <div className="flex items-center gap-3">
              <img
                src="/vakinha-logo-light.png"
                alt="Vakinha"
                className="h-8 w-auto object-contain filter brightness-110"
              />
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-6 h-6 text-gray-800" fill="currentColor">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.666 4.771-4.919 4.919-1.266.058-1.645.07-4.85.07-3.204 0-3.584-.012-4.849-.07-4.358-.2 6.78 2.618 6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.667.072 4.948.196-4.354-2.617-6.78-6.979-6.98-1.281-.057-1.689-.072-4.949-.072zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </div>
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-6 h-6 text-gray-800" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-green-400 text-xl font-semibold mb-6">Links rápidos</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <ul className="space-y-3 text-gray-300">
                  <li className="hover:text-white cursor-pointer">Quem somos</li>
                  <li className="hover:text-white cursor-pointer">Vaquinhas</li>
                  <li className="hover:text-white cursor-pointer">Criar vaquinhas</li>
                  <li className="hover:text-white cursor-pointer">Login</li>
                  <li className="hover:text-white cursor-pointer">Vaquinhas mais amadas</li>
                  <li className="hover:text-white cursor-pointer">Política de privacidade</li>
                  <li className="hover:text-white cursor-pointer">Termos de uso</li>
                </ul>
              </div>
              <div>
                <ul className="space-y-3 text-gray-300">
                  <li className="hover:text-white cursor-pointer">Dúvidas frequentes</li>
                  <li className="hover:text-white cursor-pointer">Taxas e prazos</li>
                  <li className="hover:text-white cursor-pointer">Loja de corações</li>
                  <li className="hover:text-white cursor-pointer">Vakinha Premiada</li>
                  <li className="hover:text-white cursor-pointer">Blog do Vakinha</li>
                  <li className="hover:text-white cursor-pointer">Segurança e transparência</li>
                  <li className="hover:text-white cursor-pointer">Busca por recibo</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-green-400 text-xl font-semibold mb-6">Fale conosco</h3>
            <div className="text-gray-300 space-y-2">
              <p className="hover:text-white cursor-pointer">Clique aqui para falar conosco</p>
              <div className="mt-4">
                <p>De Segunda à Sexta</p>
                <p>Das 9:30 às 17:00</p>
              </div>
            </div>
            <div className="mt-6 flex justify-end">
              <div className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9 12l2 2 4-4"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <div className="text-xs">
                  <div className="font-semibold">SELO DE</div>
                  <div>SEGURANÇA</div>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-green-400 text-xl font-semibold mb-6">Baixe nosso App</h3>
            <div className="flex gap-4">
              <div className="bg-black rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:bg-gray-900 transition-colors">
                <svg viewBox="0 0 24 24" className="w-8 h-8 text-white" fill="currentColor">
                  <path d="M18.71,19.5C17.88,20.74 17,21.95 15.66,21.97C14.32,22 13.89,21.18 12.37,21.18C10.84,21.18 10.37,21.95 9.1,22C7.79,22.05 6.8,20.68 5.96,19.47C4.25,17 2.94,12.45 4.7,9.39C5.57,7.87 7.13,6.91 8.82,6.88C10.1,6.86 11.32,7.75 12.11,7.75C12.89,7.75 14.37,6.68 15.92,6.84C16.57,6.87 18.39,7.1 19.56,8.82C19.47,8.88 17.39,10.1 17.41,12.63C17.44,15.65 20.06,16.66 20.09,16.67C20.06,16.74 19.67,18.11 18.71,19.5M13,3.5C13.73,2.67 14.94,2.04 15.94,2C16.07,3.17 15.6,4.35 14.9,5.19C14.21,6.04 13.07,6.7 11.95,6.61C11.8,5.46 12.36,4.26 13,3.5Z" />
                </svg>
                <div className="text-white">
                  <div className="text-xs">DISPONÍVEL NO</div>
                  <div className="text-sm font-semibold">Google Play</div>
                </div>
              </div>
              <div className="bg-black rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:bg-gray-900 transition-colors">
                <svg viewBox="0 0 24 24" className="w-8 h-8 text-white" fill="currentColor">
                  <path d="M18.71,19.5C17.88,20.74 17,21.95 15.66,21.97C14.32,22 13.89,21.18 12.37,21.18C10.84,21.18 10.37,21.95 9.1,22C7.79,22.05 6.8,20.68 5.96,19.47C4.25,17 2.94,12.45 4.7,9.39C5.57,7.87 7.13,6.91 8.82,6.88C10.1,6.86 11.32,7.75 12.11,7.75C12.89,7.75 14.37,6.68 15.92,6.84C16.57,6.87 18.39,7.1 19.56,8.82C19.47,8.88 17.39,10.1 17.41,12.63C17.44,15.65 20.06,16.66 20.09,16.67C20.06,16.74 19.67,18.11 18.71,19.5M13,3.5C13.73,2.67 14.94,2.04 15.94,2C16.07,3.17 15.6,4.35 14.9,5.19C14.21,6.04 13.07,6.7 11.95,6.61C11.8,5.46 12.36,4.26 13,3.5Z" />
                </svg>
                <div className="text-white">
                  <div className="text-xs">Baixar na</div>
                  <div className="text-sm font-semibold">App Store</div>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-6 text-center text-gray-400">
            © 2025 - Todos direitos reservados
          </div>
        </div>
      </footer>
    </div>
  )
}
