export function VakinhaLogo({ className = "h-8" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Ícone SVG do V no balão */}
      <svg viewBox="0 0 40 40" className="h-full w-auto" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Balão de fala verde */}
        <rect x="2" y="2" width="28" height="22" rx="6" fill="#22c55e" />
        {/* Cauda do balão */}
        <path d="M8 24 L12 30 L16 24" fill="#22c55e" />
        {/* Letra V branca */}
        <path
          d="M10 8 L15 20 L20 8"
          stroke="white"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
      </svg>

      {/* Texto vakinha */}
      <span className="text-2xl font-bold text-green-600 font-sans">vakinha</span>
    </div>
  )
}
